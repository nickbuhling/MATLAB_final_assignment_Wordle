% TO DO:

% Showing which letters are already used
    % I'm thinking of using the space on the side of the board (so using
    % the width, and not putting it underneath) to show a plot matrix with
    % all the letters of the alphabet. Those not used can be WHITE. Those
    % used and not in the word can be GREY. The ones that are yellow in the
    % board can be YELLOW, and the ones green on the board can be GREEN.

% Showing a message when the word was guessed correctly

% Showing the time how long it took to guess the word when guessed
% correclty

% Asking if you want to play another round

% Showing a message when you have not guessed the word within 6 attempts,
% and telling what the word was

% More optional: Storing statistics in a file. For example avarage time to
% guess, average guesses needed, amount of times played, amount of times
% guessed correclty, win percentage, current streak, histogram of amount of
% guesses needed etc. 