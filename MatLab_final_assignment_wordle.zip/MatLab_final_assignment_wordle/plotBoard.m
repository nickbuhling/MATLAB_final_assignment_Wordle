function plotBoard(figureToPlotIn, solutionWord, guessesMatrix)
FONT_SIZE = 20;
CENTER = 0.5;

% These colors were sampled from an image of the common version of the game
% found at https://brandmentions.com/wiki/images/c/cd/Wordle_logo.png
WHITE = '#FFFFFF';
GREY = '#787C7F';
YELLOW = '#C9B457';
GREEN = '#6BAA65';

numberOfRows = size(guessesMatrix, 1);
numberOfColumns = size(guessesMatrix, 2);

fig = figureToPlotIn;

% Initialize subplot position
currentPlotLocation = 1;

for currentRow = 1:numberOfRows
    for currentColumn = 1:numberOfColumns
        % Within the subplot with the amount of columns and rows specified,
        % make a plot at the current printing location.
        subplot(numberOfRows, numberOfColumns, currentPlotLocation, 'Parent', fig);

        % Making sure the height and width of the axis is the same
        axis square;

        % Removing the axis ticks and numbers
        set(gca, 'XTick', []);
        set(gca, 'YTick', []);

        % axis off did not work in combination with a background color, so
        % this sets the x and y axes colors to 'none' to achieve the same
        % effect. Inspired by: https://nl.mathworks.com/matlabcentral/answers/1636675-axis-off-sets-background-color-back-to-white-despite-set-gca
        set(gca, 'XColor', 'none')
        set(gca, 'YColor', 'none')

        % Writing the letter (if any)to this axis (in uppercase)
        letter = guessesMatrix(currentRow, currentColumn);
        
        text(CENTER, CENTER, upper(letter), 'Color', WHITE, 'FontName', 'Arial Bold', 'FontSize', FONT_SIZE, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle');

        if letter == 0
            % Setting background color of this square to white
            set(gca, 'Color', WHITE); 
        else
            color = evaluateLetterColor(letter, currentColumn, solutionWord, GREY, YELLOW, GREEN);
            set(gca, 'Color', color);
        end

        currentPlotLocation = currentPlotLocation + 1;
    end
end

end

% a subfunction that returns a numerical number of whether letters correspond
% to the solution word. 1 is letter in the right location.

function color = evaluateLetterColor(letter, currentColumn, solutionWord, GREY, YELLOW, GREEN)
    % Getting the letter that is supposed to be in this axis, based on
    % the solution word.
    solutionLetterAtThisLocation = solutionWord{1}(currentColumn);

    if letter == solutionLetterAtThisLocation
        color = GREEN;
    elseif contains(solutionWord, letter)
        color = YELLOW;
    else
        color = GREY;
    end
end



% if strcmpi(guessedWord, randomSolutionWord)
%     disp('Correct!')
% else 
%     disp('Not correct...')
% end

