function guessedWord = requestWordInput(fileWithValidGuessWords, fileWithSolutionWords)
% Asking the user to input a 5-letter word. Storing this as lower case
% character array, like the words in the .txt files
guessedWord = lower(input('Guess a 5-letter word: ', 's'));

% Combining the words from both .txt files into one array for validity
% checking, using the subfunction getWordsFromFile
allValidWords = [getWordsFromFile(fileWithValidGuessWords); getWordsFromFile(fileWithSolutionWords)];

% Validating the user input and asking re-entry as long as it is invalid.
% A word is valid if it is 5 characters, only letters and a member of the
% combined list of words 'allValidWords' (checked in lower case).
while length(guessedWord) ~= 5 || all(isletter(guessedWord)) == false || ismember(guessedWord, allValidWords) == false
    if length(guessedWord) ~= 5 || all(isletter(guessedWord)) == false
        disp('Invalid input. Please enter a 5-letter word and try again.');
    elseif ismember(guessedWord, allValidWords) == false
        disp('This word is not found in the list. Please choose another word.');
    end

    guessedWord = lower(input('Enter your guess: ', 's'));
end
end


% This subfunction returns the words stored in the lines of a .txt file
function words = getWordsFromFile(fileName)
fid = fopen(fileName, 'r');

% Throw an error when the file name does not exist
if fid == -1
    error('Error in getWordsFromFile: the input file does not exist.');
end

% Reading all words from the file and storing them in a cell array
words = textscan(fid, '%s', 'Delimiter', '\n');
% Extracting the words from the cell array and converting it to a regular array
words = words{1};

fclose(fid);

end