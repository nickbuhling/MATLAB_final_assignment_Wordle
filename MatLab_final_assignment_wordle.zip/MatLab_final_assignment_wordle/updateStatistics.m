function updateStatistics(attemptsDone, allowedAttempts)

% Loading the existing statistics
load('wordleUserStatistics.mat');

gamesPlayed = gamesPlayed + 1;

% Checing if the word was guessed, and based on that adding 1 to gamesWon 
% and the streak, or adding one to gamesLost and resetting the streak to 0
if attemptsDone <= allowedAttempts
    gamesWon = gamesWon + 1;
    currentStreak = currentStreak + 1;
else
    gamesLost = gamesLost + 1;
    currentStreak = 0;
end

if currentStreak > maxStreak
    maxStreak = currentStreak;
end

winPercentage = (gamesWon / gamesPlayed) * 100;

% Saving the updated statistics back to the file
save('wordleUserStatistics.mat', "gamesPlayed", "gamesWon", "gamesLost", ...
    "winPercentage", "currentStreak", "currentStreak", "maxStreak");

end