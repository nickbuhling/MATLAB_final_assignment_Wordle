clear; clc; close all;

%% CONSTANTS
SOLUTION_WORDS_FILE = "wordle_words\solutionWords.txt";
VALID_GUESS_WORDS_FILE = "wordle_words\validGuessWords.txt";

BOARD_ROWS = 6; % Represents the allowed attempts
BOARD_COLUMNS = 5; % Represents the word lenght; 5 for these datasets

%% INITIALIZING STATISTICS
% If no previous statistics file can be found, create one
initializeStatistics()

%% GETTING RANDOM SOLUTION WORD
% Getting a random solution word from the 'solutionWords.txt' file using
% the getRandomSolutionWord function
solutionWord = getRandomSolutionWord(SOLUTION_WORDS_FILE);

%% INITIALIZING GUESSES-MATRIX & FIGURE TO PRINT IN
% Initializing the matrix that holds the guessed letters. It is initialized
% as a character array with zeros (i.e. no characters). Later, each guess
% can be input into a row of this matrix based on the guessCount.
guessesMatrix = char(zeros(BOARD_ROWS, BOARD_COLUMNS));

% Creating the figure to plot the board into. This figure gets
% automatically docked within this matlab window above the command window.
fig = figure('WindowStyle', 'docked', 'Name', 'Wordle');

%% PLOTTING THE BOARD AT START AND FOR EVERY GUESS
plotBoard(fig, solutionWord, guessesMatrix)
% Bringing the figure to focus, otherwise it is hidden in a tab
figure(fig);

guessCount = 1; % Stores how many guesses have been done for a word

while true
    % Requesting the user to input a word using the requestWordInput function.
    % This function also checks the validity of the entered word
    guessedWord = requestWordInput(VALID_GUESS_WORDS_FILE, SOLUTION_WORDS_FILE);

    % Add the attempt to the matrix of guesses (the playing board essentially),
    % in the correct row according to the guessCount
    guessesMatrix(guessCount,:) = guessedWord;

    plotBoard(fig, solutionWord, guessesMatrix)

    if guessedWord == char(solutionWord)
        wordGuessed = true;
        break
    end

    guessCount = guessCount + 1;

    if guessCount > 6
        wordGuessed = false;
        break
    end
end

%% CONCLUDING ROUND BASED ON PERFORMANCE AND UPDATING STATISTICS
% Updating the statistics based on this games performance
updateStatistics(guessCount, BOARD_ROWS)

if wordGuessed
    showEndOfGameMessage(1, solutionWord) % 1 means won
else
    showEndOfGameMessage(0, solutionWord) % 0 means lost
end






