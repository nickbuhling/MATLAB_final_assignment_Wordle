clear; clc; close all;

SOLUTION_WORDS_FILE = "wordle_words\solutionWords.txt";
VALID_GUESS_WORDS_FILE = "wordle_words\validGuessWords.txt";

BOARD_ROWS = 6;
BOARD_COLUMNS = 5;

% Getting a random solution word from the 'solutionWords.txt' file using
% the getRandomSolutionWord function
solutionWord = getRandomSolutionWord(SOLUTION_WORDS_FILE)

guessCount = 0; % Stores how many guesses have been done for a word

% Initializing the matrix that holds the guessed letters. It is initialized
% as a character array with zeros (i.e. no characters). Later, each guess
% can be input into a row of this matrix based on the guessCount.
guessesMatrix = char(zeros(BOARD_ROWS, BOARD_COLUMNS));

% Creating the figure to plot the board into. This figure gets
% automatically docked within this matlab window above the command window.
fig = figure('WindowStyle', 'docked', 'Name', 'Wordle');
plotBoard(fig, solutionWord, guessesMatrix)
% Bringing the figure to focus, otherwise it is hidden in a tab
figure(fig);

while guessCount < 6
    % Requesting the user to input a word using the requestWordInput function.
    % This function also checks the validity of the entered word
    guessedWord = requestWordInput(VALID_GUESS_WORDS_FILE, SOLUTION_WORDS_FILE);

    % Add the attempt to the matrix of guesses (the playing board essentially),
    % in the correct row according to the guessCount
    guessesMatrix(guessCount + 1,:) = guessedWord;

    plotBoard(fig, solutionWord, guessesMatrix)

    guessCount = guessCount + 1;
end



