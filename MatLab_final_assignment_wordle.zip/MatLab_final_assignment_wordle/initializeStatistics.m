function initializeStatistics()
% Checking if a statistics file already exists
if ~exist('wordleUserStatistics.mat', 'file')
    % If not, initialize the variables for Wordle statistics
    gamesPlayed = 0;
    gamesWon = 0;
    gamesLost = 0;
    winPercentage = 0;
    currentStreak = 0;
    maxStreak = 0;

    save('wordleUserStatistics.mat'); % Saving it so it can be updated later
end

end
