function randomSolutionWord = getRandomSolutionWord (fileWithSolutionWords)
% Opening the dataset of solution words
fid = fopen(fileWithSolutionWords, 'r');
% Throw an error when the file name does not exist
if fid == -1
    error('Error in getRandomSolutionWord.m: The file you are trying to open does not exist.');
end

% Reading in all the lines of the opened file and counting how many lines
% are inside the file
numberOfLines = 0;
while ~(feof(fid))
    fgetl(fid); % Getting a line
    numberOfLines = numberOfLines + 1;
end

% Generating a random number between 0 and numberOfLines in order to pick
% a random word from the list
randomLineNumber = randi(numberOfLines);

% Resetting the file pointer to the beginning of the file
frewind(fid);

% Reading 1 line (as a string (%s)) at a time, with '\n' as the delimiter,
% skipping 'randomLineNumber-1' lines to get the word at 'randomLineNumber'
randomSolutionWord = textscan(fid,'%s',1,'delimiter','\n','headerlines',randomLineNumber-1);
% Extracting the word from the 1x1 cell array to get the string intself
randomSolutionWord = randomSolutionWord{1}{1};

fclose(fid);

end