function showEndOfGameMessage(result, solutionWord)
    load('wordleUserStatistics.mat');

    % Format the string with the win percentage formatting options of 
    % sprintf. '%.0f' to get zero decimal places. '%%' to print'%' symbol:
    % https://nl.mathworks.com/help/matlab/ref/sprintf.html
    winPercentageString = sprintf('%.0f%% wins', round(winPercentage));
    gamesPlayedString = sprintf('Games played: %d', gamesPlayed);
    currentStreakString = sprintf('Current streak: %d', currentStreak);
    maxStreakString = sprintf('Max streak: %d', maxStreak);
    solutionString = sprintf('The solution was: %s', upper(solutionWord));

    if result == 1 % WON
        % Creating a cell array with the lines of text that are to be printed
        % in the message box
        messageLines = {"CONGRATULATIONS, YOU WON!", '', gamesPlayedString, ...
            winPercentageString, currentStreakString, maxStreakString};
    
        winIcon = imread('img/WIN_icon.jpg');
        msgbox(messageLines, 'Success', 'custom', winIcon);
    end

    if result == 0 % LOST
        % Creating a cell array with the lines of text that are to be printed
        % in the message box
        messageLines = {"TOO BAD, YOU DID NOT GUESS THE WORD...", '', ...
            solutionString, '', gamesPlayedString, winPercentageString, ...
            currentStreakString, maxStreakString};
    
        loseIcon = imread('img/sad_emoticon_icon.png');
        msgbox(messageLines, 'Oh no!', 'custom', loseIcon);
    end


end